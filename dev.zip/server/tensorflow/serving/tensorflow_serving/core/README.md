Directory for non-application-specific modules.
