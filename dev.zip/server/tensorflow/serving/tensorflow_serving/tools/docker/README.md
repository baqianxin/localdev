Files for using the [Docker](http://www.docker.com) container system.
Please see [Docker instructions](https://github.com/tensorflow/serving/blob/master/tensorflow_serving/g3doc/docker.md)
for more info.
